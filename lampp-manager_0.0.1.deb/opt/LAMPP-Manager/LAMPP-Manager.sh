echo '#################### Welcome to LAMPP Manager ####################'
echo ''
echo 'This terminal window was opened so that you can work with administrator privileges without having to enter the sudo password in each action.'
echo 'Do not close that window, just minimize it.'
echo ''
echo 'Enjoy!'

cd /opt/LAMPP-Manager/;
./LAMPP\ Manager